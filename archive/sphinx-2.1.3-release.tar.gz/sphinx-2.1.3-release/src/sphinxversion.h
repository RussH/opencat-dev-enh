#define SPH_SVN_TAG "release"
#define SPH_SVN_REV 4319
#define SPH_SVN_REVSTR "4319"
#define SPH_SVN_TAGREV "r4319"
